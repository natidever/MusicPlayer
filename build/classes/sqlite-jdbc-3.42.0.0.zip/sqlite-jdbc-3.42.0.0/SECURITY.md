# Security Policy

## Supported Versions

| Version           | Supported          |
|-------------------|--------------------|
| Latest version    | :white_check_mark: |
| Any other version | :x:                |

## Reporting a Vulnerability

See https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing/privately-reporting-a-security-vulnerability#privately-reporting-a-security-vulnerability
